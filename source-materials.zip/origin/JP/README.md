# 日本原文快照说明

原项目：[japan-life-playbook](https://github.com/gerrygao1995-coder/japan-life-playbook)。作者：Gerry；原创正文许可：CC BY 4.0。

此目录保留本次中文翻译对应的日文结构化原稿，供核对条目与来源；中文读者请从[日本篇首页](../README.md)进入。JSON 的属性及条目顺序与快照一致，空白格式可能重新缩进。snapshot.json 中的 SHA-256 记录的是制作快照时源文件的原始字节。

快照时间：2026-10-08T16:32:07.231Z；正文条目：768；有内容的章节：48。
